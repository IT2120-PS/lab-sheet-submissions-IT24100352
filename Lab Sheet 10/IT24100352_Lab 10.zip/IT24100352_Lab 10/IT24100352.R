

setwd("C:\\Users\\Dell\\Desktop\\IT24100352_Lab 10")
observe <- c(120,95,85,100)
prob <- c(.25, .25, .25, .25)

chisq.test(observe)
chisq.test(observe, p = prob)